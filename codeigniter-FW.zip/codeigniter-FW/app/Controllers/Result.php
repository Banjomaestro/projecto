<?php

namespace App\Controllers;

class Result extends BaseController
{
    public function index()
    {
        return view('result/view');
    }
}
