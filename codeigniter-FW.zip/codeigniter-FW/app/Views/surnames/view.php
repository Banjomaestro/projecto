<h2><?= esc($surnames['name']) ?></h2>
<p><?= esc($surnames['surname']) ?></p>