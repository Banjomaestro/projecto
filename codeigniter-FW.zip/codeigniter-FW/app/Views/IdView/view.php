<h2><?= esc($internaute['Identifiant']) ?></h2>
<p><?= esc($internaute['mdp']) ?></p>